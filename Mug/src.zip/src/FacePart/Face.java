package FacePart;



import javafx.scene.image.Image;

public class Face extends Inspector{
    private final String fac;
    
    public Face()
    {
        this.fac = "/Image/faceb.jpg";
    }
    public Face(String f) {
        this.fac = f;  
    }
 
    public String getFace()
    {
        return fac;
    }
    public void btnAction()
    {

        counter = (counter % 3) +1;
        if (counter == 1)
        {
           iv.setImage(new Image("/Image/facey.jpg")); 
        }else if (counter == 2)
        {
            iv.setImage(new Image("/Image/facep.jpg"));
        }else
        {
            iv.setImage(new Image("/Image/faceb.jpg"));
        } 
    }
}
