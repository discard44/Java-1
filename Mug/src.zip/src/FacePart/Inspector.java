
package FacePart;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

class Inspector extends FacePart {

    static void display(){
        //second window
        Stage second = new Stage();
        Pane pane2 = new Pane();
        Scene scene2 = new Scene(pane2, 200, 200);
        face = new Face("/Image/faceb.jpg");
        rightEye = new Eye("/Image/eye1.png");
        leftEye = new Eye("/Image/eye1.png");
        
        Button btnChange = new Button("Change");
        btnChange.setOnAction(e -> activePart.btnAction());
        
        
        second.setScene(scene2);
        pane2.getChildren().add(btnChange);
        second.setResizable(false);
        
        second.setTitle("Inspector");
        second.show();
    }
    public void mouseClicked(MouseEvent e)  {
	FacePart.setFacePart(this);
}

    private void btnAction() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

    
}
