/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FacePart;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class FacePart extends Application {

    public int counter;
    public static Face face;
    public static Eye rightEye, leftEye;
    public static ImageView iv, iv2, iv3;
    public static Inspector activePart;

    @Override
    public void start(Stage primaryStage) {

        face = new Face();

        rightEye = new Eye();
        leftEye = new Eye();
        Pane pane = new Pane();
        Scene scene = new Scene(pane, 700, 500);

        iv = new ImageView(face.getFace());
        iv.setOnMouseClicked(e -> Inspector.display());

        iv2 = new ImageView(rightEye.getEye());
        iv2.setOnMouseClicked(e -> Inspector.display());
        
        iv2.setFitWidth(150);
        iv2.setFitHeight(150);
        iv2.setX(700 / 3.5);
        iv2.setY(500 / 3);
        
        iv3 = new ImageView(leftEye.getEye());
        iv3.setOnMouseClicked(e -> Inspector.display());

        iv3.setFitWidth(150);
        iv3.setFitHeight(150);
        iv3.setX(700 / 2);
        iv3.setY(500 / 3);

        primaryStage.setScene(scene);
        pane.getChildren().addAll(iv, iv2, iv3);

        primaryStage.setResizable(false);
        primaryStage.setTitle("Facial");
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }


    public static void setFacePart(Inspector f)  {
   		activePart = f;
   		
    } 

}
