
package FacePart;

import javafx.scene.image.Image;

public class Eye extends Face {
    private final String eyeImage;
    public Eye() {
        this.eyeImage = "/Image/eye1.png";
    }
    public Eye(String f)
    {
        this.eyeImage = f; 
    }
    public String getEye()
    {
        return eyeImage;
    }
    @Override
    public void btnAction()
    {
        counter = (counter % 3) +1;
        if (counter == 1)
        {
           iv2.setImage(new Image("/Image/eye2.png")); 
           iv3.setImage(new Image("/Image/eye2.png"));
        }else if (counter == 2)
        {
           iv2.setImage(new Image("/Image/eye3.png"));
           iv3.setImage(new Image("/Image/eye3.png"));
        }else
        {
           iv2.setImage(new Image("/Image/eye1.png"));
           iv3.setImage(new Image("/Image/eye1.png"));
        } 
    }
        

}
